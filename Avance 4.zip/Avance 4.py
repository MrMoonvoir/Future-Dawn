#Sistema de combate
hp_jugador = 100
hp_enemigo = 150

def turno_de_jugador():
    global hp_jugador, hp_enemigo
    print("Tu turno:")
    print("1. Atacar con: Espada de madera")
    print("2. Curarte con: Pocion")
    action = input("Elige una acción (1-2): ")

    if action == "1":
        damage = random.randint(5, 8, 10, 15, 20)
        enemy_hp -= damage
        print("Atacaste al enemigo e hiciste {damage} de daño.")
    elif action == "2":
        heal = random.randint(8, 15)
        player_hp += heal
        print("Te curaste {heal} puntos de vida.")
    else:
        print("Intentalo de nuevo")

#hud
print("¡Comienza el combate!")
while hp_jugador > 0 and hp_enemigo > 0:
    turno_de_jugador()
    if hp_enemigo <= 0:
        break
    turno_de_enemigo()

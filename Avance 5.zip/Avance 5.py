import random
#Sistema de combate
player_hp = 100
enemy_hp = 150

def turno_de_jugador():
    global player_hp, enemy_hp
    print ("Tu turno:")
    print ("1. Atacar con: Espada de madera")
    print ("2. Curarte con: Pocion")
    action = input ("Elige una acción (1-2): ")
    
# jugador
    if action == "1":
        damage = random.randint(4, 13)
        enemy_hp -= damage
        print ("Atacas y pierde {damage} HP")
    elif action == "2":
        heal = random.randint(6, 9)
        player_hp += heal
        print ("Te curaste {heal} puntos de vida.")
    else:
        print ("Te acabas de distraer")
        
# enemigo
def turno_de_enemigo():
    global hp_jugador, hp_enemigo
    print ("Turno del enemigo...")
    action_enemy = random.randrange(1, 2, 3)
    
    if action_enemy == "1":
        damage = random.randint(3, 16)
        player_hp -= damage
        print ("Haz perdido {damage} HP")
    elif action_enemy == "2":
        heal = 8
        enemy_hp += heal
        print("El enemigo a recuperado 8 HP")
    elif action_enemy == "3":
        print("Enemigo: ¡¡DEBILUCHO!! Nunca me podras derrotar. (Turno Extra)")
#hud
print("¡Comienza el combate!")
while player_hp > 0 and enemy_hp > 0:
    turno_de_jugador()
    if enemy_hp <= 0:
        break
    turno_de_enemigo()
    if player_hp <= 0:
        break

# Buscando una forma de reportar cuanto daño a recibido la unidad, ciclo funciona correctamente

def entrar_juego():
    print("Future Dawn: The unclear destiny")

def pedir_nombre():
    nombre = input("Tap ur name")
    print("Que tal viajero, te atreves a pasar a esta torre, sera mejor que retrocedas y dejes morir a tu pueblo")
    return nombre

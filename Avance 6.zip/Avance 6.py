import random
#Sistema de combate
player_hp = 100
enemy_hp = 150
# Mostrando estado de HP
def barras_de_vida():
    print("Tu HP", player_hp, "--vs-- HP del enemigo", enemy_hp)

def turno_de_jugador():
    global player_hp, enemy_hp
    print ("\n---Tu turno---")
    print ("1. Atacar con: Espada de madera")
    print ("2. Curarte con: Pocion")
    action = input ("Elige una acción (1-2): ")
    
# jugador
    if action == "1":
        damage = random.randint(4, 13)
        enemy_hp -= damage
        print ("\n Atacas y pierde", damage,"HP")
    elif action == "2":
        heal = random.randint(6, 9)
        player_hp += heal
        print ("\n Te curaste", heal,"puntos de vida.")
    else:
        print ("\n Te acabas de distraer")
        
# enemigo

def turno_de_enemigo():
    global player_hp, enemy_hp
    print("\n--- Turno del enemigo ---")
    action_enemy = random.choice(["1", "2"])

    if action_enemy == "1":
        damage = random.randint(3, 16)
        player_hp -= damage
        print(f"El enemigo te ataca y pierdes", damage,"HP.")
    elif action_enemy == "2":
        heal = 8
        enemy_hp += heal
        print("El enemigo usa una poción y recupera 8 HP.")

#hud
print("¡Comienza el combate!")

while player_hp > 0 and enemy_hp > 0:
    turno_de_jugador()
    if enemy_hp <= 0:
        break

    turno_de_enemigo()
    if player_hp <= 0:
        break
    
if player_hp <= 0:
    print("\n...Descanse en paz guerrero...")
    print("Fin del juego")
    
elif enemy_hp <= 0:
    print("\n¡Has derrotado al enemigo!")


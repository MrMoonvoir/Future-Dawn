def entrar_juego():
    print("Future Dawn")

def pedir_nombre():
    nombre = input("Tap ur name")
    return pedir_nombre
print("Que tal viajero, te atreves a pasar a esta torre, sera mejor que retrocedas y dejes morir a tu pueblo. Elige tu arma principal: ¿espada, hacha, o lanza?")

def arma():
    if weapon = espada:
        return arma()
print("La arma elegida es: ESPADA")
#PDT: Posiblemente haya translado de proyecto por la complejidad del proyecto
                
        

                
            
        
